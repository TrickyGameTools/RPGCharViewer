# RPGCharViewer
A tool I use for character savegame analysis


![RPG Viewer](https://github.com/TrickyGameTools/RPGCharViewer/blob/master/RPGCharViewer.png?raw=true)

This tool can be used for true character data analysis in savegames saved with engines using the RPGChar database engine.
The systems currently supporting that are LAURA II and DuCraL. (Please note the original LAURA does not use this engine and is thus not supported by this tool).

Games currently supporting this tool are: 
- Star Story
- The Fairy Tale REVAMPED

This tool is only a viewer. Data cannot be ´hacked´ with it (not to mention that games could even be protected against actual ´hacking´ and this tool does not know what security protocols could be used).
You may use it in case you´d like to create something yourself with the LAURA II engine. Or you can see what data is stored in the named games, for what good it may do :P
